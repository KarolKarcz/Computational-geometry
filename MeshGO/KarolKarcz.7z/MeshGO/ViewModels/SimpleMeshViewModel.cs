﻿using Caliburn.Micro;
using System;
using System.Collections.Generic;
using System.Text;

namespace MeshGO.ViewModels
{
    class SimpleMeshViewModel : Screen
    {
    }
}
