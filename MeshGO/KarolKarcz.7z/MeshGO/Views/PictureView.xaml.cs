﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MeshGO.Views
{
    /// <summary>
    /// Logika interakcji dla klasy PictureView.xaml
    /// </summary>
    public partial class PictureView : UserControl
    {
        public PictureView()
        {
            InitializeComponent();

            //Cnva.Children[0].SetValue(Image.WidthProperty, 100.0);
            //Cnva.Children[0].SetValue(Image.HeightProperty, 100.0);

        }

        //----------------------------------------------------------------------Click methods----------------------------------------------------------------------//

        private void GENERATE_Click(object sender, RoutedEventArgs e)
        {

        }

        private void fileLoad_Click(object sender, RoutedEventArgs e)
        {


            GENERATE.IsEnabled = true;
     
        }

        //----------------------------------------------------------------------Validation----------------------------------------------------------------------//

        private void fileTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (fileTextBox.Text != "")
            {
                fileLoad.IsEnabled = true;
            }
            else
            {
                fileLoad.IsEnabled = false;
            }
        }

        //----------------------------------------------------------------------File operation----------------------------------------------------------------------//

        private void readImage()
        {
            string docPath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
        }
    }
}
